```js
// Must define a state to store the selected value
// The value of the selected option must be passed to the state
const [selectedValue, setSelectedValue] = useState('option_1')

<Picker
    options={[
        { value: 'option_1', name: 'Option 1' },
        { value: 'option_2', name: 'Option 2' },
        ...
    ]}
    onChange={selectedValue}
    value={setSelectedValue}
/>  
```